//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CommAssit.rc
//
#define IDD_COMMASSIT_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_COM_DIALOG                  130
#define IDC_TAB                         1000
#define IDC_COMBO_COM_BAUDRATE          1003
#define IDC_COMBO_COM_DATABITS          1005
#define IDC_CHECK_NET_SENDHEX2          1017
#define IDC_EDIT_SEND                   1025
#define IDC_COMBO_COM_VERIFYBITS        1029
#define IDC_COMBO_COM_STOPBITS          1031
#define IDC_COMBO_COM_PORT              1033
#define IDC_BUTTON_COM_OPEN             1035
#define IDC_CHECK_COM_RECVHEX           1037
#define IDC_CHECK_COM_WRITEFILE         1039
#define IDC_EDIT_COM_SAVEPATH           1041
#define IDC_BUTTON_COM_PATH_SELECT      1043
#define IDC_BUTTON_COM_STOPDISPLAY      1045
#define IDC_BUTTON_COM_REDISPLAY        1047
#define IDC_BUTTON_COM_CLEARDISPLAY     1048
#define IDC_BUTTON_COM_SAVE             1049
#define IDC_CHECK_COM_SENDHEX           1050
#define IDC_CHECK_COM_SEND_LOOP         1051
#define IDC_EDIT_COM_SENDPERIOD         1052
#define IDC_EDIT_COM_SENDFILEPATH       1053
#define IDC_BUTTON_COM_SENDFILEPATH_SELECT 1054
#define IDC_EDIT1                       1054
#define IDC_EDIT_COM_CURRENT            1054
#define IDC_BUTTON_COM_SEND_CMD         1055
#define IDC_BUTTON_COM_SEND_FILE        1056
#define IDC_EDIT_COM_VOLTAGE            1056
#define IDC_EDIT_COM_SEND_LENGTH        1057
#define IDC_EDIT_COM_RECV_LENGTH        1058
#define IDC_RICHEDIT_COM_SEND           1059
#define IDC_RICHEDIT_COM_RECV           1060
#define IDC_BUTTON_COM_PATH_SELECT2     1061
#define IDC_EDIT_COM_SOC                1061
#define IDC_BUTTON_COM_REFRESHPORT      1062
#define IDC_EDIT_COM_TEMP               1063
#define IDC_EDIT_COM_QUANTITY           1064
#define IDC_EDIT_COM_INDEX              1065
#define IDC_EDIT6                       1067

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1068
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
